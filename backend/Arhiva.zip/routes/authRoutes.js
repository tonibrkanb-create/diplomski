const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// registration endpoint
router.post('/register', authController.register);
// login endpoint
router.post('/login', authController.login);

module.exports = router;