const authService = require('../services/authService');
const jwt = require('jsonwebtoken');

const getJwtSecret = () => process.env.JWT_SECRET || 'change-me-in-production';

const createToken = (user) => jwt.sign(
  { id: user.id, username: user.username },
  getJwtSecret(),
  { expiresIn: '24h' }
);

class AuthController {
  async register(req, res) {
    try {
      const user = await authService.register(req.body);
      const safeUser = { id: user.id, username: user.username };
      const token = createToken(safeUser);
      res.status(201).json({ user: safeUser, token });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async login(req, res) {
    try {
      const user = await authService.login(req.body.username, req.body.password);
      const token = createToken(user);
      res.json({ user, token });
    } catch (error) {
      res.status(401).json({ message: error.message });
    }
  }
}

module.exports = new AuthController();