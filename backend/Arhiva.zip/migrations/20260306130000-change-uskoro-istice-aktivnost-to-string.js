'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.changeColumn('uskoro_istice', 'aktivnost', {
      type: Sequelize.STRING,
      allowNull: false
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.changeColumn('uskoro_istice', 'aktivnost', {
      type: Sequelize.ENUM(
        'ZastitaNaRadu',
        'ZastitaOdPozara',
        'ZastitaOkolisa',
        'OstalaMjerenja'
      ),
      allowNull: false
    });
  }
};
