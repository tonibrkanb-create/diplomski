'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addColumn('documents', 'blob', {
      type: Sequelize.BLOB('long'),
      allowNull: true
    });
  },

  async down(queryInterface) {
    await queryInterface.removeColumn('documents', 'blob');
  }
};