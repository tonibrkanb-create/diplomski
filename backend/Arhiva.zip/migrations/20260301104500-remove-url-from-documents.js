'use strict';

module.exports = {
  async up(queryInterface) {
    await queryInterface.removeColumn('documents', 'url');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.addColumn('documents', 'url', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: ''
    });
  }
};